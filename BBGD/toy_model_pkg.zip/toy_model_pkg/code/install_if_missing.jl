function install_if_missing(pkg_name)
    # Check if package is installed
    installed = try
        eval(Meta.parse(string("using ", pkg_name)))
        true
    catch
        false
    end

    # Install if not installed
    if !installed
        Pkg.add(pkg_name)
    end
end