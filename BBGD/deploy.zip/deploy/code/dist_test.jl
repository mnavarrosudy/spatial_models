using Pkg
Pkg.add("KDEstimation")
using Distributions, JLD2, Plots, KDEstimation

# Get the path of the main directory
main_dir = dirname(@__DIR__)

mc_data = load_object(joinpath(main_dir, "data", "montecarlo_data.jld2"))
new_cols = [mc_data[:, 3] .+ mc_data[:, 5] mc_data[:, 4] .+ mc_data[:, 5] mc_data[:, 3] .+ mc_data[:, 6] mc_data[:, 4] .+ mc_data[:, 6]]
mc_data_new = [mc_data new_cols]
iteration = 1;
sigma_max = 0.009;
select_rows = (mc_data_new[:, 2] .== sigma_max .&& mc_data_new[:, 1] .== iteration);
mc_data_subset = mc_data_new[select_rows, :]

# Productivity period 0
plot(mc_data_subset[:, 3], mc_data_subset[:, 7], seriestype=:scatter, mc=:red, ms=2, ma=0.5, legend = false)
title!("Productivity in period 0")
xlabel!("Productivity (a)")
ylabel!("Productivity + Error (a+e0)")
xlims!(0, percentile(mc_data_subset[:, 3], 50))
ylims!(0, percentile(mc_data_subset[:, 3], 50))


b_range = range(0, 5, length=20)
histogram(mc_data_subset[:, 3], bins=b_range, normalize=:pdf)
histogram!(mc_data_subset[:, 7], normalize=:pdf)

# Amenity period 0
plot(mc_data_subset[:, 4], mc_data_subset[:, 8], seriestype=:scatter, mc=:blue, ms=2, ma=0.5, legend = false)
title!("Amenity in period 0")
xlabel!("Amenity (b)")
ylabel!("Amenity + Error (b+e0)")
xlims!(0, percentile(mc_data_subset[:, 4], 50))
ylims!(0, percentile(mc_data_subset[:, 4], 50))

# Productivity period 1
plot(mc_data_subset[:, 3], mc_data_subset[:, 9], seriestype=:scatter, mc=:green, ms=2, ma=0.5, legend = false)
title!("Productivity in period 1")
xlabel!("Productivity (a)")
ylabel!("Productivity + Error (a+e1)")
xlims!(0, percentile(mc_data_subset[:, 3], 50))
ylims!(0, percentile(mc_data_subset[:, 3], 50))

# Amenity period 0
plot(mc_data_subset[:, 4], mc_data_subset[:, 10], seriestype=:scatter, mc=:purple, ms=2, ma=0.5, legend = false)
title!("Amenity in period 1")
xlabel!("Amenity (b)")
ylabel!("Amenity + Error (b+e1)")
xlims!(0, percentile(mc_data_subset[:, 4], 50))
ylims!(0, percentile(mc_data_subset[:, 4], 50))

quantile(mc_data_subset[:, 3], 0.75)
percentile(mc_data_subset[:, 3], 75)
mean(mc_data[:, 4])