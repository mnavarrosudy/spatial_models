# Load the package manager
using Pkg

# Get the path of the main directory
main_dir = dirname(@__DIR__)

println("The main directory is: ", main_dir)

# Get the path of the file directory
file_dir = dirname(@__FILE__)

println("This script is in the directory: ", file_dir)