using Pkg
using JLD2

# Get the path of the main directory
main_dir = dirname(@__DIR__)

# Get the path of the file directory
file_dir = dirname(@__FILE__)

# Directory path to results
res_dir = joinpath(main_dir, "res", "montecarlo_iterations");

files = [file for file in readdir(res_dir) if isfile(abspath(joinpath(res_dir, file)))];

# All files in results directory
all_files = [file for file in readdir(res_dir) if isfile(abspath(joinpath(res_dir, file)))];

# Julia format files in results directory
jld2_files = [m.match for m in match.(r".*\.jld2", all_files) if m !== nothing];

# CSV format files in results directory
csv_files = [m.match for m in match.(r".*\.csv", all_files) if m !== nothing];

# Vector containing in each element the result matrix of every iteration
mc_res = load_object.(joinpath.(res_dir, jld2_files));

# Matrix with the stacked results
mc_res_combined = reduce(vcat, mc_res)

jld2_files[:, jld213:14]

strip(jld2_files[1], [mc_iteration_'])

typeof(jld2_files[1])

reduce(hcat, jld2_files)
strip.(jld2_files, ["mc_iteration_"])