include("mc_iteration.jl")

montecarlo_iteration(7)