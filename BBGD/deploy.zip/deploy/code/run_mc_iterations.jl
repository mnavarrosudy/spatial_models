# Get the path of the main directory
main_dir = dirname(@__DIR__)

# Get the path of the file directory
file_dir = dirname(@__FILE__)

include(joinpath(file_dir, "mc_iteration.jl"))
include(joinpath(file_dir, "shortest_path.jl"))
include(joinpath(file_dir, "sigma_upperbound.jl"))

function run_montecarlo_iterations(ite_ini, ite_fin = ite_ini)

    ###############
    ### Options ###
    ###############

    # Optimization method
    opt_method = 1; # 1: Brent's method

    # Error structure
    error_struct = 1; # 1: Additive; 2: Multiplicative

    # Error structure
    moment_struct = 1; # 1: Additive; 2: Multiplicative

    # Sigma to scale the log normal distribution for productivity and amenities (i.e. fundamentals)
    sigma_fund = 1;

    # Sigma upperbound to scale the normal distribution of the structural errors (to avoid negative values) 
    sigma_ub = sigma_upperbound(sigma_fund);

    # Sigmas to scale the standard normal distribution of the structural errors
    nsigmas = 4;
    sigmas_error = collect(range(0, sigma_ub, length = nsigmas)); # Vector{Float64}
    
    ###############
    ### Network ###
    ###############

    # Number of locations
    N = 11;

    # Number of observations
    nobs = N * N;
    
    # Calculate shortest paths in period 0 and period 1
    sp_0, sp_1 = shortest_path(N)

    # Read montecarlo data
    data_dir = joinpath(main_dir, "data", "montecarlo_data.jld2")
    mc_data = load_object(data_dir);

    # Verbose
    if (opt_method == 1)
        opt_method_name = "Brent's method"
    elseif (opt_method == 2)
        opt_method_name = "Nelder-Mead method"
    end

    if error_struct == 1
        error_struct_name = "Additive"
    else
        error_struct_name = "Multiplicative"
    end

    if moment_struct == 1
        moment_struct_name = "Additive"
    else
        moment_struct_name = "Multiplicative"
    end

    println("Starting estimation of theta using ", opt_method_name, ", ", error_struct_name, " error, and ", moment_struct_name, " 'moment'.")

    for i in ite_ini:ite_fin
        println("Iteration ", i, ":")
        select_rows = mc_data[:, 1] .== i
        mc_data_subset = mc_data[select_rows, :]
        montecarlo_iteration(i, nobs, error_struct, moment_struct, sigma_fund, sigmas_error, mc_data, sp_0, sp_1)
    end
end