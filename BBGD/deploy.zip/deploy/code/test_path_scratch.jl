

if Sys.iswindows()
	serverid = "WB_mtlb_3"
	base_path = "D:/WBS/BBGD/stuff"
elseif Sys.isapple()
	serverid = "MN_mac"
	base_path = "/Users/mnavarrosudy/Dropbox/BBGD/code"
elseif Sys.islinux()
	try 
        # Reminder: try is a local scope, so if we want to keep something defined within it need to store as global
        global serverid = read("/home/wb547641/server_identifier.txt", String)    # Expecting WB_linuxX_userAM
		global base_path = "/Users/wb547641/deploy"
	catch
		try 
            global serverid = read("/home/610020/server_identifier.txt", String)  	# Expecting WB_linuxX_userMN
			global base_path = "/Users/wb547641/deploy"
		catch 
			try 
                global serverid = read("/home/aim/.server_identifier.txt", String) 	# Expecting AM_at or AM_cl or AM_do
				global base_path = "/home/aim/Dropbox/BBGD/code"
			catch
				println("Server is linux, but server identifier file not found")
            end
        end
	end
else
	println("OS unknown")
end


# Maybe override the base path depending on whether AM_at or AM_cl

println(base_path)
println(serverid) #the stuff that is in file we read

cd(base_path)

include("mc_simulation.jl")

