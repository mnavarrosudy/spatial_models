using Distributions

function sigma_upperbound(sigma_fund)
    function f(sigma)
        normal_min = quantile(Normal(0,sigma), 0.0001)
        lognormal_min = exp(quantile(Normal(0,sigma_fund), 0.0001))
        Q = (lognormal_min + normal_min)^2
        return Q
    end

    res = optimize(f, 0.0, 1.0);
    sigma = floor(Optim.minimizer(res)[1], digits = 4);
    return sigma
end