function dist_btw_nodes(adj_matrix, distmx, edgevalue, edgecolor, tau, nobs, tc_0, tc_1)
    # Fill the transportation costs matrix by link
    for i in 1:nobs
        for n in 1:nobs
            if i != n && adj_matrix[i, n] == 1
                row_i, col_i = divrem(i - 1, 11)  # Get row and column of node i
                row_n, col_n = divrem(n - 1, 11)  # Get row and column of node n
                dist_i = tau[row_i + 1, col_i + 1]  # Get distance value for node i
                dist_n = tau[row_n + 1, col_n + 1]  # Get distance value for node n
                
                if row_i == row_n || col_i == col_n
                    distmx[i, n] = (dist_i + dist_n) / 2
                else
                    distmx[i, n] = sqrt(2) * (dist_i + dist_n) / 2
                end
            elseif adj_matrix[i, n] == 2
                distmx[i, n] = 1.0
            end
        end
    end
    
    # Store the transportation cost corresponding to each edge
    for i in 1:nobs
        for j in i+1:nobs
            if isfinite(distmx[i, j])
                edgevalue[(i, j)] = distmx[i, j]
            end
        end
    end

    # Assign colors to each edge
    for (index, value) in pairs(edgevalue)
        if value == tc_1
            edgecolor[index] = colorant"rgb(38, 70, 83)"
        elseif value == sqrt(2)*(tc_1+tc_1)/2
            edgecolor[index] = colorant"rgb(40, 114, 113)"
        elseif value == (tc_0+tc_1)/2
            edgecolor[index] = colorant"rgb(42, 157, 143)"
        elseif value == sqrt(2)*(tc_0+tc_1)/2
            edgecolor[index] = colorant"rgb(138, 177, 125)"
        elseif value == tc_0
            edgecolor[index] = colorant"rgb(233, 196, 106)"
        elseif value == sqrt(2)*(tc_0+tc_0)/2
            edgecolor[index] = colorant"rgb(244, 162, 97)"
        else
            edgecolor[index] = colorant"rgb(231, 111, 81)"
        end
    end

    return distmx, edgevalue, edgecolor
end