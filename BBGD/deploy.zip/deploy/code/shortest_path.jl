using Pkg
#Pkg.add("Graphs")
#Pkg.add("GraphRecipes")
#Pkg.add("Plots")
using LinearAlgebra, Graphs, GraphRecipes, Plots

include("dist_btw_nodes.jl")

function shortest_path(N)

    # Number of observations
    nobs = N * N;

    # Create empty graph for period 0
    graph_0 = Graph(nobs);

    # Create empty graph for period 1
    graph_1 = Graph(nobs);

    # Add edges between adjacent nodes and nodes in diagonals
    for i in 1:N, j in 1:N
        node = (i - 1) * N + j
        neighbors = [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1), (i - 1, j - 1), (i - 1, j + 1), (i + 1, j - 1), (i + 1, j + 1)]
        for (ni, nj) in neighbors
            if ni in 1:N && nj in 1:N
                neighbor_node = (ni - 1) * N + nj
                add_edge!(graph_0, node, neighbor_node)
                add_edge!(graph_1, node, neighbor_node)
            end
        end
    end

    # Add self-loop to each node
    #for node in 1:nobs
    #    add_edge!(graph_0, node, node)
    #    add_edge!(graph_1, node, node)
    #end

    # Nodes location
    x = Float64[];
    y = Float64[];

    for i = N:-1:1, j = N:-1:1 # Decrementing loop such that node 1 is at the upper left corner
        push!(x, j)
        push!(y, i)
    end

    # Adjancency matrices
    adj_matrix_0 = adjacency_matrix(graph_0);
    adj_matrix_1 = adjacency_matrix(graph_1);

    # Transportation costs
    tc_0 = 7.9; # Without bridges
    tc_1 = 1; # With bridges

    # Transportation costs matrix by node in period 0
    tau_0 = fill(tc_0, N, N);
    #tau_0[:, 6] .= tc_1;
    #tau_0[6, :] .= tc_1;
    tau_0

    # Transportation costs matrix by node in period 1
    tau_1 = fill(tc_0, N, N);
    tau_1[:, 6] .= tc_1;
    tau_1[6, :] .= tc_1; 
    tau_1

    # Create transportation costs matrix by link in period 0
    distmx_0 = fill(Inf, nobs, nobs);  # Initialize with Inf
    edgevalue_0 = Dict();
    edgecolor_0 = Dict();
    distmx_0, edgevalue_0, edgecolor_0 = dist_btw_nodes(adj_matrix_0, distmx_0, edgevalue_0, edgecolor_0, tau_0, nobs, tc_0, tc_1);

    # Create transportation costs matrix by link in period 1
    distmx_1 = fill(Inf, nobs, nobs);  # Initialize with Inf
    edgevalue_1 = Dict();
    edgecolor_1 = Dict();
    distmx_1, edgevalue_1, edgecolor_1 = dist_btw_nodes(adj_matrix_1, distmx_1, edgevalue_1, edgecolor_1, tau_1, nobs, tc_0, tc_1);

    # Plot of network in period 0
    graphplot(graph_0, x = x, y = y, edgecolor = edgecolor_0, edgewidth = (s,d,w) -> 1.5, curves = false, nodesize = 0.5, nodeshape = :circle)

    # Plot of network in period 1
    graphplot(graph_1, x = x, y = y, edgecolor = edgecolor_1, edgewidth = (s,d,w) -> 1.5, curves = false, nodesize = 0.5, nodeshape = :circle)

    # Shortest path matrix
    shortest_path_0 = zeros(nobs, nobs);
    shortest_path_1 = zeros(nobs, nobs);

    for i in 1:nobs
        shortest_path_0[i, :] = dijkstra_shortest_paths(graph_0, i, distmx_0).dists
        shortest_path_1[i, :] = dijkstra_shortest_paths(graph_1, i, distmx_1).dists
    end

    shortest_path_0[diagind(shortest_path_0)] .= 1.0;
    shortest_path_1[diagind(shortest_path_1)] .= 1.0;

    return shortest_path_0, shortest_path_1
end